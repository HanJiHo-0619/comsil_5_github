﻿#include "tetris.h"
#include <ncurses.h>

static struct sigaction act, oact;

int main(){
	int exit=0;

	initscr();
	noecho();
	keypad(stdscr, TRUE);	

	srand((unsigned int)time(NULL));

	while(!exit){
		clear();
		switch(menu()){
		case MENU_PLAY: play(); break;
		case MENU_RANK: createRankList; rank(); break;
		case MENU_RECOMMENDED_PLAY: recommendedPlay(); break;
		case MENU_EXIT: exit=1; break;
		default: break;
		}
	}

	endwin();
	system("clear");
	return 0;
}

void InitTetris(){
	int i,j;

	for(j=0;j<HEIGHT;j++)
		for(i=0;i<WIDTH;i++)
			field[j][i]=0;

	nextBlock[0]=rand()%7;
	nextBlock[1]=rand()%7;
	nextBlock[2]=rand()%7; //assignment 2 code
	blockRotate=0;
	blockY=-1;
	blockX=WIDTH/2-2;
	score=0;	
	gameOver=0;
	timed_out=0;

	DrawOutline();
	DrawField();
	DrawBlockWithFeatures(blockY,blockX,nextBlock[0],blockRotate); //assignment1 code
	DrawNextBlock(nextBlock);
	PrintScore(score);
}

//assignment 2 code
void DrawOutline(){	
	int i,j;
	/* 블럭이 떨어지는 공간의 태두리를 그린다.*/
	DrawBox(0,0,HEIGHT,WIDTH);

	/* 1번째 next block을 보여주는 공간의 태두리를 그린다.*/
	move(2,WIDTH+10);
	printw("NEXT BLOCK");
	DrawBox(3,WIDTH+10,4,8);

	//2번째 next block을 보여주는 공간의 테두리를 그린다.
	DrawBox(9, WIDTH + 10, 4, 8);
	
	/* score를 보여주는 공간의 태두리를 그린다.*/
	move(15,WIDTH+10);
	printw("SCORE");
	DrawBox(16,WIDTH+10,1,8);
}

int GetCommand(){
	int command;
	command = wgetch(stdscr);
	switch(command){
	case KEY_UP:
		break;
	case KEY_DOWN:
		break;
	case KEY_LEFT:
		break;
	case KEY_RIGHT:
		break;
	case ' ':	/* space key*/
		/*fall block*/
		break;
	case 'q':
	case 'Q':
		command = QUIT;
		break;
	default:
		command = NOTHING;
		break;
	}
	return command;
}

int ProcessCommand(int command){
	int ret=1;
	int drawFlag=0;
	switch(command){
	case QUIT:
		ret = QUIT;
		break;
	case KEY_UP:
		if((drawFlag = CheckToMove(field,nextBlock[0],(blockRotate+1)%4,blockY,blockX)))
			blockRotate=(blockRotate+1)%4;
		break;
	case KEY_DOWN:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX)))
			blockY++;
		break;
	case KEY_RIGHT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX+1)))
			blockX++;
		break;
	case KEY_LEFT:
		if((drawFlag = CheckToMove(field,nextBlock[0],blockRotate,blockY,blockX-1)))
			blockX--;
		break;
	default:
		break;
	}
	if(drawFlag) DrawChange(field,command,nextBlock[0],blockRotate,blockY,blockX);
	return ret;	
}

void DrawField(){
	int i,j;
	for(j=0;j<HEIGHT;j++){
		move(j+1,1);
		for(i=0;i<WIDTH;i++){
			if(field[j][i]==1){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(".");
		}
	}
}


//assignment 2 code
void PrintScore(int score){
	move(16,WIDTH+11);
	printw("%8d",score);
}

//assignment 2 code
void DrawNextBlock(int *nextBlock){
	int i, j;
	for( i = 0; i < 4; i++ ){
		move(4+i,WIDTH+13);
		for( j = 0; j < 4; j++ ){
			if( block[nextBlock[1]][0][i][j] == 1 ){
				attron(A_REVERSE);
				printw(" ");
				attroff(A_REVERSE);
			}
			else printw(" ");
		}
	}

	for (i = 0; i < 4; i++) {
		move(10 + i, WIDTH + 13);
			for (j = 0; j < 4; j++) {
				if (block[nextBlock[2]][0][i][j] == 1) {
					attron(A_REVERSE);
					printw(" ");
					attroff(A_REVERSE);
				}
				else printw(" ");
			}
	}
}

void DrawBlock(int y, int x, int blockID,int blockRotate,char tile){
	int i,j;
	for(i=0;i<4;i++)
		for(j=0;j<4;j++){
			if(block[blockID][blockRotate][i][j]==1 && i+y>=0){
				move(i+y+1,j+x+1);
				attron(A_REVERSE);
				printw("%c",tile);
				attroff(A_REVERSE);
			}
		}

	move(HEIGHT,WIDTH+10);
}

void DrawBox(int y,int x, int height, int width){
	int i,j;
	move(y,x);
	addch(ACS_ULCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_URCORNER);
	for(j=0;j<height;j++){
		move(y+j+1,x);
		addch(ACS_VLINE);
		move(y+j+1,x+width+1);
		addch(ACS_VLINE);
	}
	move(y+j+1,x);
	addch(ACS_LLCORNER);
	for(i=0;i<width;i++)
		addch(ACS_HLINE);
	addch(ACS_LRCORNER);
}

void play(){
	int command;
	clear();
	act.sa_handler = BlockDown;
	sigaction(SIGALRM,&act,&oact);
	InitTetris();

	//추천 시스템 추가
	recRoot = (RecNode*)malloc(sizeof(RecNode));
	recRoot->lv = 0;
	recRoot->score = 0;
	recRoot->f = (char (*)[WIDTH])malloc(sizeof(char) * HEIGHT * WIDTH);
	memcpy(recRoot->f, field, sizeof(char) * HEIGHT * WIDTH);
	recommend(recRoot); 

	do{
		if(timed_out==0){
			alarm(1);
			timed_out=1;
		}

		command = GetCommand();
		if(ProcessCommand(command)==QUIT){
			alarm(0);
			DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
			move(HEIGHT/2,WIDTH/2-4);
			printw("Good-bye!!");
			refresh();
			getch();

			return;
		}
	}while(!gameOver);

	alarm(0);
	getch();
	DrawBox(HEIGHT/2-1,WIDTH/2-5,1,10);
	move(HEIGHT/2,WIDTH/2-4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
}

char menu(){
	printw("1. play\n");
	printw("2. rank\n");
	printw("3. recommended play\n");
	printw("4. exit\n");
	return wgetch(stdscr);
}

/////////////////////////첫주차 실습에서 구현해야 할 함수/////////////////////////

int CheckToMove(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	for (int i=0; i <= 3; i++) {
		for (int j=0; j <= 3; j++) {
			if (block[currentBlock][blockRotate][i][j] == 1){
				if (blockY + i >= HEIGHT)
					return 0;
				if (blockX + j >= WIDTH || blockX + j < 0)
					return 0;
				if (f[blockY + i][blockX + j] == 1)
					return 0;
			}
		}
	}
	return 1;
}

void DrawChange(char f[HEIGHT][WIDTH],int command,int currentBlock,int blockRotate, int blockY, int blockX){
	int Rotate = blockRotate ;
	int pre_X = blockX;
	int pre_Y = blockY;

	switch (command) {
	case KEY_UP: Rotate = (Rotate + 3) % 4;
		break;
	case KEY_DOWN: pre_Y -= 1;
		break;
	case KEY_RIGHT:pre_X -= 1;
		break;
	case KEY_LEFT: pre_X ++;
		break;
	default:
		break;
	}
	int shadowY = pre_Y;
	while (CheckToMove(field, currentBlock, Rotate, shadowY + 1, pre_X)) {
		shadowY++;
	}
	for (int i = 0; i <= 3; i++) {
		for (int j = 0; j <= 3; j++) {
			if (block[currentBlock][Rotate][i][j] == 1) {
				if (pre_Y + i >= 0) {
					move(pre_Y + i + 1, pre_X + j + 1);
					printw(".");
				}
				if (shadowY + i >= 0) {
					move(shadowY + i + 1, pre_X + j + 1);
					printw(".");
				}
			}
		}
	}
	//추천시스템 추가
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (block[nextBlock[0]][blockRotate][i][j] == 1 && recommendY + i >= 0) {
				if (field[recommendY + i][recommendX + j] == 0) {
					move(recommendY + i + 1, recommendX + j + 1);
					printw(".");
				}
			}
		}
	}
	DrawBlockWithFeatures(blockY, blockX, currentBlock, blockRotate);
}

void BlockDown(int sig){
	if((CheckToMove(field,nextBlock[0],blockRotate,blockY+1,blockX))){
		blockY++;
		DrawChange(field, KEY_DOWN, nextBlock[0], blockRotate, blockY, blockX);
	}
	else {
		if (blockY == -1) {
			gameOver = 1;
		}
		score += AddBlockToField(field, nextBlock[0], blockRotate, blockY, blockX); //assignment 3 code
		score += DeleteLine(field);
		DrawField();

		//assignment 2 code
		nextBlock[0] = nextBlock[1];
		nextBlock[1] = nextBlock[2];
		nextBlock[2] = rand() % 7;

		blockRotate = 0;
		blockX = WIDTH / 2 - 2;
		blockY = -1;	

		free(recRoot->f);
		free(recRoot);
		recRoot = (RecNode*)malloc(sizeof(RecNode));
		recRoot->f = (char (*)[WIDTH])malloc(sizeof(char) * HEIGHT * WIDTH);
		memcpy(recRoot->f, field, sizeof(char) * HEIGHT * WIDTH);
		recRoot->lv = 0;
		recRoot->score = 0;
		recommend(recRoot);

		DrawNextBlock(nextBlock);
		PrintScore(score);
		DrawField();
	}
	timed_out = 0;
}

//assignment 3 code
int AddBlockToField(char f[HEIGHT][WIDTH],int currentBlock,int blockRotate, int blockY, int blockX){
	int touched = 0;
	for (int i = 0; i <= 3; i++) {
		for (int j = 0; j <= 3; j++) {
			if (block[currentBlock][blockRotate][i][j] == 1) {
				f[blockY + i][blockX + j] = 1;
				if (HEIGHT - 1 == blockY + i) {
					touched++;
				}
			}
		}
	}
	return touched * 10;
}

int DeleteLine(char f[HEIGHT][WIDTH]){
	int fline;     
	int count = 0; 
	for (int i = 0; i < HEIGHT; i++) {
		fline = 1; 

		for (int j = 0; j < WIDTH; j++) {
			if (f[i][j] == 0) {
				fline = 0;
				break;
			}
		}
		if (fline == 1) {
			count++;

			for (int k = i; k > 0; k--) {
				for (int m = 0; m < WIDTH; m++) {
					f[k][m] = f[k - 1][m];
				}
			}

			for (int m = 0; m < WIDTH; m++) {
				f[0][m] = 0;
			}
			i--;
		}
	}

	return count * count * 100;
}

///////////////////////////////////////////////////////////////////////////

//assignment 1 code
void DrawShadow(int y, int x, int blockID,int blockRotate){
	while (CheckToMove(field, blockID, blockRotate, y+1, x)) {
		y++;
	}
	DrawBlock(y, x, blockID, blockRotate, '/');
}

//assignment 1 code
//recommend 추가
void DrawBlockWithFeatures(int y, int x, int blockID, int blockRotate) {
	DrawRecommend(recommendY, recommendX, blockID, recommendR);
	DrawShadow(y, x, blockID, blockRotate);
	DrawBlock(y, x, blockID, blockRotate, ' ');
}


//동적 배열을 위한 전역 변수 설정
char** rank_name = NULL;
int* rank_score = NULL;
int rank_size = 0;
int rank_volume = 0;

void createRankList() {
	FILE* fp;
	//1. 파일 열기
	fp = fopen("rank.txt", "r");

	//2. 정보 읽어 오기
	if (fp != NULL) {
		fscanf(fp, "%d", &rank_size);
		//기존에 있던 메모리 해제
		if (rank_name != NULL) {
			for (int i = 0; i < rank_size; i++) {
				free(rank_name[i]);
			}
			free(rank_name);
			free(rank_score);
		}
		//배열 초기화
		rank_volume = rank_size;
		rank_name = (char**)malloc(sizeof(char*) * rank_volume);
		rank_score = (int*)malloc(sizeof(int) * rank_volume);

		for (int j = 0; j < rank_size; j++) {
			rank_name[j] = (char*)malloc(sizeof(char) * (NAMELEN+1));
			fscanf(fp, "%s %d", rank_name[j], &rank_score[j]);
		}
		// 4. 파일닫기
		fclose(fp);
	}
	else {
		printw("Warning : rank.txt not found\n");
		refresh();
		rank_size = 0;
		rank_volume = 0;
	}
}

void rank() {
	//목적: rank 메뉴를 출력하고 점수 순으로 X부터~Y까지 출력함
	createRankList();

	//1. 문자열 초기화(초기 X, Y를 0으로 설정해 이후 입력 없을 경우 대비)
	int X = 0, Y = 0, ch;
	clear();

	//2. printw()로 3개의 메뉴출력 
	printw("1. List ranks from X to Y\n");
	printw("2. List ranks by a specific name\n");
	printw("3. Delete a specific rank X\n");

	//3. wgetch()를 사용하여 변수 ch에 입력받은 메뉴번호 저장
	ch = wgetch(stdscr);

	//4. 각 메뉴에 따라 입력받을 값을 변수에 저장
	//4-1. 메뉴1: X, Y를 입력받고 적절한 input인지 확인 후(X<=Y), X와 Y사이의 rank 출력
	if (ch == '1') {
		echo();
		printw("X: ");
		scanw("%d", &X);
		printw("Y: ");
		scanw("%d", &Y);
		noecho();

		printw(" %-16s| %-12s\n", "name", "score");
		printw("-------------------------------\n");
		
		//입렵 값이 없을때
		if (X == 0 && Y == 0) {
			for (int i = 0; i < rank_size; i++) {
				printw(" %-16s| %-12d\n", rank_name[i], rank_score[i]);
			}
		}
		//X만 입력 값이 없을 때
		else if (X == 0 && Y != 0) {
			if (Y > rank_size || Y < 1) {
				printw("search failure: no rank in the list\n");
			}
			else {
				for (int j = 0; j < Y; j++) {
					printw(" %-16s| %-12d\n", rank_name[j], rank_score[j]);
				}
			}
		}
		//Y만 입력 값이 없을 때
		else if (X != 0 && Y == 0) {
			if (X > rank_size || X < 1) {
				printw("search failure: no rank in the list\n");
			}
			else {
				for (int k = X - 1; k < rank_size; k++) {
					printw(" %-16s| %-12d\n", rank_name[k], rank_score[k]);
				}
			}
		}
		//둘 다 입력값이 있을 때
		else {
			if (X > Y || X < 1 || Y > rank_size) {
				printw("search failure: no rank in the list\n");
			}
			else {
				for (int m = X - 1; m < Y; m++) {
					printw(" %-16s| %-12d\n", rank_name[m], rank_score[m]);
				}
			}
		}
	}
	//4-2. 메뉴2: 문자열을 받아 저장된 이름과 비교하고 이름에 해당하는 리스트를 출력
	else if (ch == '2') {
		echo();
		char searchname[NAMELEN + 1];
		int cnt = 0;
		printw("input the name: ");
		scanw("%s", searchname);
		noecho();
		printw(" %-16s| %-12s\n", "name", "score");
		printw("-------------------------------\n");

		for (int i = 0; i < rank_size; i++) {
			if (strcmp(rank_name[i], searchname) == 0) {
				printw(" %-16s| %-12d\n", rank_name[i], rank_score[i]);
				cnt = 1;
			}
		}
		if (!cnt) {
			printw("\nsearch failure : the rank not in the list");
		}
	}
	//4-3. 메뉴3: rank번호를 입력받아 리스트에서 삭제
	else if (ch == '3'){
		echo();
		int del_rank;
		printw("input the rank: ");
		scanw("%d", &del_rank);
		noecho();

		if (del_rank <1 || del_rank > rank_size) {
			printw("\nsearch failure : the rank not in the list");
		}
		else {
			free(rank_name[del_rank - 1]);
			for (int i = del_rank - 1; i < rank_size - 1; i++) {
				rank_name[i] = rank_name[i + 1];
				rank_score[i] = rank_score[i + 1];
			}
			rank_size--;
			printw("\nresult: the rank deleted\n");

			writeRankFile();
		}
	}
	refresh();
	getch();
}
	

	
	

void writeRankFile() {
	// 목적: 추가된 랭킹 정보가 있으면 새로운 정보를 "rank.txt"에 쓰고 없으면 종료
	//1. "rank.txt" 연다
	FILE* fp = fopen("rank.txt", "w");
	if (fp == NULL) {
		printw("Warning : rank.txt not found\n");
		refresh();
		getch();
		return;
	}
	//2. 랭킹 정보들의 수를 "rank.txt"에 기록
	fprintf(fp, "%d\n", rank_size);
	//3. 탐색할 노드가 더 있는지 체크하고 있으면 다음 노드로 이동, 없으면 종료
	for (int i = 0; i < rank_size; i++) {
		fprintf(fp, "%s %d\n", rank_name[i], rank_score[i]);
	}
	fclose(fp);
	//4.메모리 해제
	for (int j = 0; j < rank_size; j++) {
		free(rank_name[j]);
	}
	free(rank_name);
	free(rank_score);

	rank_name = NULL;
	rank_score = NULL;
	rank_size = 0;
	rank_volume = 0;
}

void newRank(int score) {
	// 목적: GameOver시 호출되어 사용자 이름을 입력받고 score와 함께 리스트의 적절한 위치에 저장
	createRankList();
	
	char str[NAMELEN + 1];
	clear();
	
	//1. 사용자 이름을 입력받음
	echo();
	printw("Your Name: ");
	scanw("%s", str);
	noecho();

	// 동적 배열 크기 할당
	if (rank_size == rank_volume) {
		if (rank_volume == 0) {
			rank_volume = 10;
		}
		else {
			rank_volume = rank_volume * 2;
		}
		rank_name = realloc(rank_name, sizeof(char*) * rank_volume);
		rank_score = realloc(rank_score, sizeof(int) * rank_volume);
	}

	//2. 새로운 노드를 생성해 이름과 점수를 저장, score_number가
	rank_name[rank_size] = malloc(sizeof(char) * NAMELEN);
	strncpy(rank_name[rank_size], str, NAMELEN);
	rank_score[rank_size] = score;
	rank_size++;

	//score 기준 정렬 
	for (int i = rank_size - 1; i > 0; i--) {
		if (rank_score[i] > rank_score[i - 1]) {
			int tempt_score = rank_score[i];
			rank_score[i] = rank_score[i - 1];
			rank_score[i - 1] = tempt_score;

			char* tempt_name = rank_name[i];
			rank_name[i] = rank_name[i - 1];
			rank_name[i - 1] = tempt_name;
		}
		else {
			break;
		}
	}
	writeRankFile();
}

void DrawRecommend(int y, int x, int blockID, int blockRotate) {
	//user code
	while (CheckToMove(field, blockID, blockRotate, y + 1, x)) {
	y++;
    }
	//R나오게 그리기
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 4; j++) {
			if (block[blockID][blockRotate][i][j] == 1 && y + i >= 0) {
				if (field[y + i][x + j] == 0) { 
					move(y + i + 1, x + j + 1);
					attron(A_BOLD);
					printw("R");
					attroff(A_BOLD);
				}
			}
		}
	}
}


int recommend(RecNode* root) {
	int max = -1;
	int cnt = 0;
	int blockID = nextBlock[root->lv];

	for (int i = 0; i < 4; i++) {
		for (int x = -2; x <= WIDTH - BLOCK_WIDTH; x++) {
			int y = -1;
			while (CheckToMove(root->f, blockID, i, y + 1, x)) y++;
			if (y < 0 || y >= HEIGHT) continue;

			RecNode* child = (RecNode*)malloc(sizeof(RecNode));
			child->f = (char (*)[WIDTH])malloc(sizeof(char) * HEIGHT * WIDTH);
			memcpy(child->f, root->f, sizeof(char) * HEIGHT * WIDTH);
			child->lv = root->lv + 1;
			child->score = root->score;
			child->score += AddBlockToField(child->f, blockID, i, y, x);
			child->score += DeleteLine(child->f);
			root->c[cnt++] = child;

			int result;
			if (child->lv < BLOCK_NUM)
				result = recommend(child);
			else
				result = child->score;

			if (result > max || (result == max && y > recommendY)) {
				if (CheckToMove(root->f, blockID, i, y, x)) {
					max = result;
					if (root->lv == 0) {
						recommendR = i;
						recommendY = y;
						recommendX = x;
					}
				}
			}
		}
	}
	for (int i = 0; i < cnt; i++) {
		if (root->c[i]) {
			free(root->c[i]->f);
			free(root->c[i]);
		}
	}
	return max;
}


void recommendedPlay(){
	struct sigaction acts;
	memset(&acts, 0, sizeof(acts));
	acts.sa_handler = SIG_IGN;
	sigaction(SIGALRM, &acts, NULL);
	alarm(0);

	clear();
	refresh();

	InitTetris();
	nodelay(stdscr, TRUE);

	while (!gameOver) {
		int ch = getch();
		if (ch == 'q' || ch == 'Q') {
			gameOver = 1;
			break;
		}
		recRoot = (RecNode*)malloc(sizeof(RecNode));
		recRoot->f = (char(*)[WIDTH])malloc(sizeof(char) * HEIGHT * WIDTH);
		memcpy(recRoot->f, field, sizeof(char) * HEIGHT * WIDTH);
		recRoot->lv = 0;
		recRoot->score = 0;

		recommend(recRoot);

		int targetX = recommendX;
		int targetY = recommendY;
		int targetR = recommendR;

		if (!CheckToMove(field, nextBlock[0], targetR, targetY, targetX)) {
			gameOver = 1;
			break;
		}

		// 이동 애니메이션
		int tempY = -1;
		blockX = targetX;
		blockY = tempY;
		blockRotate = targetR;



		while (blockY < targetY) {
			if (blockY >= 0)
				DrawBlock(blockY, blockX, nextBlock[0], blockRotate, '.');

			blockY++;
			DrawField();
			DrawNextBlock(nextBlock);
			PrintScore(score);
			DrawRecommend(targetY, targetX, nextBlock[0], targetR);
			DrawBlock(blockY, blockX, nextBlock[0], blockRotate, ' ');
			DrawShadow(blockY, blockX, nextBlock[0], blockRotate);

			refresh();
			usleep(100000);
		}

		// 도착 후 고정
		score += AddBlockToField(field, nextBlock[0], blockRotate, blockY, blockX);
		score += DeleteLine(field);

		// 다음 블록으로 이동
		nextBlock[0] = nextBlock[1];
		nextBlock[1] = nextBlock[2];
		nextBlock[2] = rand() % NUM_OF_SHAPE;
		blockRotate = 0;
		blockY = -1;
		blockX = WIDTH / 2 - 2;

		DrawField();
		DrawNextBlock(nextBlock);
		PrintScore(score);

		free(recRoot->f);
		free(recRoot);

		if (!CheckToMove(field, nextBlock[0], blockRotate, blockY + 1, blockX)) {
			gameOver = 1;
		}
	}
	nodelay(stdscr, FALSE);
	DrawBox(HEIGHT / 2 - 1, WIDTH / 2 - 5, 1, 10);
	move(HEIGHT / 2, WIDTH / 2 - 4);
	printw("GameOver!!");
	refresh();
	getch();
	newRank(score);
}